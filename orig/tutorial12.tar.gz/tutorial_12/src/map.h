#include "structs.h"

extern Map map;
extern SDL_Surface *brickImage, *backgroundImage;
extern Input input;
