#include "structs.h"

extern SDL_Surface *screen;
