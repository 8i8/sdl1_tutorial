#include "structs.h"

extern SDL_Surface *screen;
extern Map map;
extern TTF_Font *font;
extern Message message;
