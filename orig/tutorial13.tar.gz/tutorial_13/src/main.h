#include "structs.h"

SDL_Surface *screen;
Map map;
Input input;
SDL_Surface *mapImages[MAX_TILES];
Cursor cursor;
TTF_Font *font;
Message message;
