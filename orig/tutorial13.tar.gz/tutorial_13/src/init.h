#include "structs.h"

extern SDL_Surface *screen;
extern TTF_Font *font;
extern Map map;
