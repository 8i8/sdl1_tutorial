#include "structs.h"

extern Map map;
extern Cursor cursor;
extern Input input;
extern SDL_Surface *mapImages[MAX_TILES];
