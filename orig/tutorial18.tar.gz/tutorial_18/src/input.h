#include "structs.h"

extern Control input, customControl;
extern Game game;
