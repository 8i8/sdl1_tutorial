#include "structs.h"

extern Entity entity[MAX_ENTITIES];
extern Entity player;
extern Game game;
extern Entity *self;
extern Control customControl;
extern Redefine redefine;
