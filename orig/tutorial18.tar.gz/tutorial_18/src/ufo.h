#include "structs.h"

extern Entity entity[MAX_ENTITIES];
