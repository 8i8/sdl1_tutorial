#include "structs.h"

extern SDL_Surface *screen, *playerImage;
extern TTF_Font *font;
extern Map map;
