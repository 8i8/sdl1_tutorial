#include "structs.h"

SDL_Surface *screen, *mapImages[MAX_TILES], *playerImage;
Map map;
Input input;
Entity player, *self;
