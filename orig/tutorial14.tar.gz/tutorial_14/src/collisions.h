#include "structs.h"

extern Entity *self;
extern Map map;
