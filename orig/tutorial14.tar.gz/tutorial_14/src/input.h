#include "structs.h"

extern Input input;
