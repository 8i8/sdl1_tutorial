#include "structs.h"

extern Entity player;
extern SDL_Surface *playerImage;
extern Input input;
extern Map map;
