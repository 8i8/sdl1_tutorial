#include "defs.h"

extern Mix_Chunk *dexterBark;
