#include "defs.h"

extern SDL_Surface *screen, *dexterImage;
extern Mix_Chunk *dexterBark;
