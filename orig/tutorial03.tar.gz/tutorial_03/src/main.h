#include "defs.h"

SDL_Surface *screen, *dexterImage;
Mix_Chunk *dexterBark;
