#include "structs.h"

extern Game game;
