#include "structs.h"

extern Entity player;
extern Input input;
