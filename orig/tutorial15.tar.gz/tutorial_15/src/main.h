#include "structs.h"

SDL_Surface *screen;
Input input;
Entity player, *self;
Animation animation[MAX_ANIMATIONS];
