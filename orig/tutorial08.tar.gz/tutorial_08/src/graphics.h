#include "structs.h"

extern SDL_Surface *screen;
extern Animation starAnim;
