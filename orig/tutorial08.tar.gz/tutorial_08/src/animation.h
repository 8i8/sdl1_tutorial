#include "structs.h"

extern Animation starAnim;
