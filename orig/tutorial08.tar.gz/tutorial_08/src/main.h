#include "structs.h"

SDL_Surface *screen;
Animation starAnim;
