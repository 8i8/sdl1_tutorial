#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "SDL/SDL.h"

#define SCREEN_WIDTH 640
#define SCREEN_HEIGHT 480

#define MAX_STARS 200
