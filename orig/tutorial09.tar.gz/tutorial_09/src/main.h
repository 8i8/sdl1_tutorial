#include "structs.h"

SDL_Surface *screen;
Star star[MAX_STARS];
