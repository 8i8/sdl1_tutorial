#include "structs.h"

extern Star star[MAX_STARS];
extern SDL_Surface *screen;
