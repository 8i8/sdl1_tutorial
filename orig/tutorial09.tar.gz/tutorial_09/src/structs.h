#include "defs.h"

typedef struct Star
{
	int x, y, speed;
} Star;
