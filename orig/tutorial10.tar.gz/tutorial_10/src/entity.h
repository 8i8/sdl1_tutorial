#include "structs.h"

extern Entity *self, entity[MAX_ENTITIES];
extern Animation animation[MAX_ANIMATIONS];
