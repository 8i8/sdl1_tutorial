#include "structs.h"

extern Animation animation[MAX_ANIMATIONS];
