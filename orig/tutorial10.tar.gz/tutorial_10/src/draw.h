#include "structs.h"

Game game;
